//
//  CISProtocol.h
//  iOSConvivaSDK
//
//  Created by Nirvaid Rathore on 16/03/16.
//  Copyright © 2016 Conviva. All rights reserved.
//
#import <Foundation/Foundation.h>
#import "CISCWSProtocol.h"


@interface CISCWSProtocolHelper : NSObject<CISCWSProtocol>

@end
