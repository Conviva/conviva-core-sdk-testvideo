//
//  CISSSDKConstants.m
//  Pods
//
//  Created by Butchi peddi on 20/02/20.
//  Copyright © 2020 Conviva. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CSSInternalConstants : NSObject

FOUNDATION_EXPORT NSString *const CIS_SSDK_PLAYBACK_METRIC_AUTO_DETECTED_CDN_IP;

FOUNDATION_EXPORT NSString *const CIS_SSDK_PLAYBACK_METRIC_AUTO_DETECTED_DROPPED_FRAMES_TOTAL;

FOUNDATION_EXPORT NSString *const CIS_SSDK_SETTINGS_HB_INTERVAL;

@end


